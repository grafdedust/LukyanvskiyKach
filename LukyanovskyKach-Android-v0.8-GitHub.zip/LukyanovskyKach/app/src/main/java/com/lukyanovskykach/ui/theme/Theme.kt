package com.lukyanovskykach.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Graphite = Color(0xFF111315)
private val Surface = Color(0xFF1A1E20)
private val SurfaceAlt = Color(0xFF242A2C)
private val Lime = Color(0xFFB7E66A)
private val TextPrimary = Color(0xFFF2F4EF)
private val TextSecondary = Color(0xFFA3ADA5)
private val DarkColors = darkColorScheme(primary = Lime, onPrimary = Color(0xFF17200D), secondary = Color(0xFF91B85A), background = Graphite, onBackground = TextPrimary, surface = Surface, onSurface = TextPrimary, surfaceVariant = SurfaceAlt, onSurfaceVariant = TextSecondary)
private val LightColors = lightColorScheme(primary = Color(0xFF527D24), onPrimary = Color.White, secondary = Color(0xFF668C3B), background = Color(0xFFF5F7F2), onBackground = Color(0xFF171B16), surface = Color.White, onSurface = Color(0xFF171B16), surfaceVariant = Color(0xFFE8EDE4), onSurfaceVariant = Color(0xFF596255))

@Composable
fun KachTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, typography = MaterialTheme.typography, content = content)
}
