package com.lukyanovskykach.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Локальный справочник продуктов. Значения указаны на 100 г продукта. */
@Entity(tableName = "food_catalog", indices = [Index("name")])
data class FoodCatalogEntity(
    @PrimaryKey val id: String,
    val name: String,
    val caloriesPer100g: Int,
    val proteinPer100g: Double,
    val fatPer100g: Double,
    val carbsPer100g: Double,
    val category: String = "Другое",
    val isCustom: Boolean = false
)
