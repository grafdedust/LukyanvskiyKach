package com.lukyanovskykach.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {
    suspend fun export(context: Context, destination: Uri) = withContext(Dispatchers.IO) {
        val db = KachDatabase.getInstance(context)
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { /* checkpoint WAL before copying */ }
        val databaseFile = context.getDatabasePath("lukyanovsky-kach.db")
        context.contentResolver.openOutputStream(destination, "w").use { raw ->
            requireNotNull(raw) { "Не удалось создать файл архива" }
            ZipOutputStream(raw).use { zip ->
                zip.putNextEntry(ZipEntry("database/lukyanovsky-kach.db")); databaseFile.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                ProfileMediaStore.profileFile(context)?.let { file -> zip.putNextEntry(ZipEntry("media/profile.jpg")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry() }
                ProfileMediaStore.galleryFiles(context).forEachIndexed { index, file -> zip.putNextEntry(ZipEntry("media/gallery/${index}_${file.name}")); file.inputStream().use { it.copyTo(zip) }; zip.closeEntry() }
                zip.putNextEntry(ZipEntry("backup-info.txt")); zip.write("Лукьяновский Кач backup\nformat=1\ncreatedAt=${System.currentTimeMillis()}\n".toByteArray()); zip.closeEntry()
            }
        }
    }

    suspend fun import(context: Context, source: Uri) = withContext(Dispatchers.IO) {
        val temp = File(context.cacheDir, "kach_restore").apply { deleteRecursively(); mkdirs() }
        context.contentResolver.openInputStream(source).use { raw ->
            requireNotNull(raw) { "Не удалось открыть архив" }
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    require(!entry.isDirectory && !entry.name.startsWith("/") && !entry.name.contains("..") && !entry.name.contains("\\")) { "Некорректный архив" }
                    val out = File(temp, entry.name)
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                    entry = zip.nextEntry
                }
            }
        }
        val dbBackup = File(temp, "database/lukyanovsky-kach.db")
        require(dbBackup.exists() && File(temp, "backup-info.txt").exists()) { "Это не архив резервной копии Лукьяновского Кача" }
        // Close Room before replacing its SQLite file.
        KachDatabase.closeForRestore()
        val liveDb = context.getDatabasePath("lukyanovsky-kach.db")
        liveDb.parentFile?.mkdirs()
        listOf(liveDb, File(liveDb.path + "-wal"), File(liveDb.path + "-shm")).forEach { it.delete() }
        dbBackup.copyTo(liveDb, true)
        ProfileMediaStore.clear(context)
        ProfileMediaStore.clearGallery(context)
        File(temp, "media/profile.jpg").takeIf { it.exists() }?.let { ProfileMediaStore.importProfile(context, it) }
        File(temp, "media/gallery").takeIf { it.exists() }?.listFiles()?.forEach { ProfileMediaStore.importGallery(context, it) }
        temp.deleteRecursively()
        // Re-open now so subsequent screens use the restored database.
        KachDatabase.getInstance(context)
    }
}
