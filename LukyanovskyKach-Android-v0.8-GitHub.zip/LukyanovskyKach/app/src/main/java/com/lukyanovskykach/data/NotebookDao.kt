package com.lukyanovskykach.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {
    @Query("SELECT * FROM notes WHERE deletedAt IS NULL ORDER BY updatedAt DESC") fun observeNotes(): Flow<List<NoteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveNote(note: NoteEntity)
    @Query("UPDATE notes SET deletedAt=:at, updatedAt=:at WHERE id=:id") suspend fun deleteNote(id: String, at: Long)

    @Query("SELECT * FROM task_lists WHERE deletedAt IS NULL ORDER BY updatedAt DESC") fun observeLists(): Flow<List<TaskListEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveList(list: TaskListEntity)
    @Query("UPDATE task_lists SET deletedAt=:at, updatedAt=:at WHERE id=:id") suspend fun deleteList(id: String, at: Long)

    @Query("SELECT * FROM tasks WHERE listId=:listId AND deletedAt IS NULL ORDER BY position, createdAt") fun observeTasks(listId: String): Flow<List<TaskEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveTask(task: TaskEntity)
    @Query("UPDATE tasks SET isCompleted=:completed, completedAt=:completedAt, updatedAt=:updatedAt WHERE id=:id") suspend fun setTaskCompleted(id: String, completed: Boolean, completedAt: Long?, updatedAt: Long)
    @Query("UPDATE tasks SET deletedAt=:at, updatedAt=:at WHERE id=:id") suspend fun deleteTask(id: String, at: Long)
}
