package com.lukyanovskykach.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.lukyanovskykach.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.UUID

@Composable private fun HealthPage(content:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp), content=content) }

@Composable fun NutritionScreen(database: KachDatabase) {
 val dao=database.healthDao(); val meals by dao.observeMeals().collectAsState(initial=emptyList()); val goal by dao.observeGoal().collectAsState(initial=null); val scope= rememberCoroutineScope()
 var add by remember { mutableStateOf(false) }; var goals by remember { mutableStateOf(false) }; var catalog by remember { mutableStateOf(false) }
 LaunchedEffect(Unit) { FoodCatalogSeeder.seed(database.foodCatalogDao()) }
 val foods by database.foodCatalogDao().observeAll().collectAsState(initial=emptyList())
 val today=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0) }.timeInMillis
 val todayMeals=meals.filter { it.eatenAt>=today }; val kcal=todayMeals.sumOf { it.calories }; val protein=todayMeals.sumOf { it.protein }; val fat=todayMeals.sumOf { it.fat }; val carbs=todayMeals.sumOf { it.carbs }
 HealthPage {
  Text("Питание",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
  Card { Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) { Text("Сегодня",fontWeight=FontWeight.Bold); Text("$kcal / ${goal?.calories ?: 2000} ккал",style=MaterialTheme.typography.headlineSmall,color=MaterialTheme.colorScheme.primary); LinearProgressIndicator(progress={ (kcal.toFloat()/(goal?.calories?:2000).coerceAtLeast(1)).coerceIn(0f,1f) },modifier=Modifier.fillMaxWidth()); Text("Б ${protein.toInt()} г · Ж ${fat.toInt()} г · У ${carbs.toInt()} г"); Text("Цель: Б ${goal?.protein?:120.0} · Ж ${goal?.fat?:70.0} · У ${goal?.carbs?:220.0} г",style=MaterialTheme.typography.bodySmall) } }
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick={add=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Text("Добавить еду")}; OutlinedButton(onClick={catalog=true},modifier=Modifier.weight(1f)){Text("Каталог")} }; OutlinedButton(onClick={goals=true},modifier=Modifier.fillMaxWidth()){Text("Настроить цели БЖУ")}
  Text("История питания",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
  if(meals.isEmpty()) Text("Записей пока нет")
  meals.forEach { m -> Card { Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(m.title,fontWeight=FontWeight.SemiBold); Text("${m.mealType} · ${SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(Date(m.eatenAt))}",style=MaterialTheme.typography.bodySmall); if(m.foodDescription.isNotBlank()) Text(m.foodDescription,style=MaterialTheme.typography.bodySmall) }; Column { Text("${m.calories} ккал",fontWeight=FontWeight.Bold); Text("Б ${m.protein.toInt()} · Ж ${m.fat.toInt()} · У ${m.carbs.toInt()}",style=MaterialTheme.typography.bodySmall); TextButton(onClick={scope.launch{dao.deleteMeal(m.id)}}){Text("Удалить")} } } } }
 }
 if(add) MealDialog({add=false}) { title,type,desc,c,p,f,carb -> scope.launch { dao.saveMeal(MealEntryEntity(UUID.randomUUID().toString(),title,type,desc,c,p,f,carb)) }; add=false }
 if(goals) GoalDialog(goal?:NutritionGoalEntity(),{goals=false}) { g->scope.launch{dao.saveGoal(g)};goals=false }
 if(catalog) FoodCatalogDialog(foods, { catalog=false }) { food, grams ->
   val factor=grams/100.0
   scope.launch { dao.saveMeal(MealEntryEntity(UUID.randomUUID().toString(),food.name,"Перекус","${grams.toInt()} г · ${food.category}",(food.caloriesPer100g*factor).toInt(),food.proteinPer100g*factor,food.fatPer100g*factor,food.carbsPer100g*factor)) }
   catalog=false
 }
}

@Composable private fun MealDialog(onDismiss:()->Unit,onSave:(String,String,String,Int,Double,Double,Double)->Unit) {
 var title by remember{mutableStateOf("")}; var type by remember{mutableStateOf("Завтрак")}; var desc by remember{mutableStateOf("")}; var kcal by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var f by remember{mutableStateOf("")};var c by remember{mutableStateOf("")}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Приём пищи")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){ OutlinedTextField(title,{title=it},label={Text("Название")}); OutlinedTextField(type,{type=it},label={Text("Тип: завтрак, обед…")}); OutlinedTextField(desc,{desc=it},label={Text("Продукты / описание")}); Row { SmallNum("Ккал",kcal,{kcal=it},Modifier.weight(1f));SmallNum("Белки",p,{p=it},Modifier.weight(1f)) };Row{SmallNum("Жиры",f,{f=it},Modifier.weight(1f));SmallNum("Углеводы",c,{c=it},Modifier.weight(1f))} }},confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(title,type,desc,kcal.toIntOrNull()?:0,p.toDoubleOrNull()?:0.0,f.toDoubleOrNull()?:0.0,c.toDoubleOrNull()?:0.0)}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}
@Composable private fun GoalDialog(goal:NutritionGoalEntity,onDismiss:()->Unit,onSave:(NutritionGoalEntity)->Unit){var kcal by remember{mutableStateOf(goal.calories.toString())};var p by remember{mutableStateOf(goal.protein.toString())};var f by remember{mutableStateOf(goal.fat.toString())};var c by remember{mutableStateOf(goal.carbs.toString())};AlertDialog(onDismissRequest=onDismiss,title={Text("Цели на день")},text={Column{SmallNum("Ккал",kcal,{kcal=it});SmallNum("Белки, г",p,{p=it});SmallNum("Жиры, г",f,{f=it});SmallNum("Углеводы, г",c,{c=it})}},confirmButton={TextButton(onClick={onSave(NutritionGoalEntity(calories=kcal.toIntOrNull()?:2000,protein=p.toDoubleOrNull()?:120.0,fat=f.toDoubleOrNull()?:70.0,carbs=c.toDoubleOrNull()?:220.0))}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})}

@Composable fun MedicationsScreen(database:KachDatabase){val dao=database.healthDao();val meds by dao.observeMedications().collectAsState(initial=emptyList());val logs by dao.observeMedicationLogs().collectAsState(initial=emptyList());val scope= rememberCoroutineScope();var adding by remember{mutableStateOf(false)}; val context=LocalContext.current
 val notificationPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if(granted) android.widget.Toast.makeText(context,"Разрешение получено. Напоминания можно включить в карточке препарата.",android.widget.Toast.LENGTH_SHORT).show() }
 HealthPage { Text("Препараты и добавки",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Журнал учёта приёма. Он не назначает лечение и не заменяет рекомендации врача.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant);Button(onClick={adding=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Text("Добавить препарат")};if(meds.isEmpty())Text("Добавьте препарат или добавку для ведения журнала")
 meds.forEach { med -> Card { Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(med.name,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Text("${med.dosage} ${med.unit} · ${med.schedule}");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ listOf("TAKEN" to "Принято","SKIPPED" to "Пропущено","DELAYED" to "Отложено").forEach{(status,label)->TextButton(onClick={scope.launch{dao.saveMedicationLog(MedicationLogEntity(UUID.randomUUID().toString(),med.id,med.name,"${med.dosage} ${med.unit}",status,System.currentTimeMillis(),if(status=="TAKEN")System.currentTimeMillis() else null))}}){Text(label)} } };TextButton(onClick={ if(android.os.Build.VERSION.SDK_INT>=33) notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS); MedicationReminderScheduler.schedule(context,med.id,med.name,"${med.dosage} ${med.unit}",9,0); android.widget.Toast.makeText(context,"Ежедневное напоминание установлено на 09:00",android.widget.Toast.LENGTH_SHORT).show() }){Text("Напоминать ежедневно в 09:00")}; TextButton(onClick={MedicationReminderScheduler.cancel(context,med.id);scope.launch{dao.archiveMedication(med.id)}}){Text("Архивировать")}} } }
 Text("История приёма",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);logs.take(30).forEach{log->Text("${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(Date(log.scheduledAt))} · ${log.medicationName} · ${log.dosage} · ${when(log.status){"TAKEN"->"Принято";"SKIPPED"->"Пропущено";else->"Отложено"}}")}
 }
 if(adding) MedicationDialog({adding=false}){name,dose,unit,schedule,note->scope.launch{dao.saveMedication(MedicationEntity(UUID.randomUUID().toString(),name,dose,unit,schedule,note=note))};adding=false}
}
@Composable private fun MedicationDialog(onDismiss:()->Unit,onSave:(String,String,String,String,String?)->Unit){var name by remember{mutableStateOf("")};var dose by remember{mutableStateOf("")};var unit by remember{mutableStateOf("мг")};var schedule by remember{mutableStateOf("1 раз в день")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Новая запись")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(name,{name=it},label={Text("Название")});OutlinedTextField(dose,{dose=it},label={Text("Дозировка")});OutlinedTextField(unit,{unit=it},label={Text("Единица")});OutlinedTextField(schedule,{schedule=it},label={Text("Расписание (текстом)")});OutlinedTextField(note,{note=it},label={Text("Заметка")})}},confirmButton={TextButton(enabled=name.isNotBlank(),onClick={onSave(name,dose,unit,schedule,note.ifBlank{null})}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})}

@Composable fun StatisticsScreen(database:KachDatabase){
 val dao=database.healthDao(); var period by remember { mutableStateOf("30 дней") }; var exportFormat by remember { mutableStateOf("csv") }
 val now=System.currentTimeMillis(); val from=when(period){"7 дней"->now-7L*86400000;"90 дней"->now-90L*86400000;"6 месяцев"->now-183L*86400000;"Год"->now-365L*86400000;"Всё время"->0L;else->now-30L*86400000}
 val allMeals by dao.observeMeals().collectAsState(initial=emptyList()); val chartMeals=allMeals.filter { it.eatenAt in from..now }; val sessions by dao.workoutCount(from,now).collectAsState(initial=0); val meals by dao.mealCount(from,now).collectAsState(initial=0); val kcal by dao.caloriesSum(from,now).collectAsState(initial=0); val protein by dao.proteinSum(from,now).collectAsState(initial=0.0); val doses by dao.dosesTaken(from,now).collectAsState(initial=0)
 val context=LocalContext.current; val scope= rememberCoroutineScope()
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){ uri -> if(uri!=null) scope.launch { runCatching { ReportExportManager.export(context,uri,exportFormat) }.onFailure { android.widget.Toast.makeText(context,"Ошибка экспорта: ${it.message}",android.widget.Toast.LENGTH_LONG).show() }.onSuccess { android.widget.Toast.makeText(context,"Отчёт сохранён",android.widget.Toast.LENGTH_SHORT).show() } } }
 HealthPage { Text("Статистика",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold); Text("Период отчёта",fontWeight=FontWeight.SemiBold)
  Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){ listOf("7 дней","30 дней","90 дней","6 месяцев","Год","Всё время").forEach { label -> FilterChip(selected=period==label,onClick={period=label},label={Text(label)}) } }
  Text("Сводка за период: $period",color=MaterialTheme.colorScheme.onSurfaceVariant)
  Text("Динамика калорий",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
  val days=when(period){"7 дней"->7;"90 дней"->30;"6 месяцев"->30;"Год"->30;"Всё время"->30;else->30}
  val buckets=(0 until days).map { index -> val dayStart=now-(days-1-index)*86400000L; val cal=Calendar.getInstance().apply{timeInMillis=dayStart;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}; val start=cal.timeInMillis; val end=start+86400000L; chartMeals.filter{it.eatenAt in start until end}.sumOf{it.calories}.toFloat() }
  val chartColor=MaterialTheme.colorScheme.primary
  Canvas(Modifier.fillMaxWidth().height(130.dp)) { if(buckets.isNotEmpty()){ val max=buckets.maxOrNull()?.coerceAtLeast(1f)?:1f; val step=size.width/(buckets.size.coerceAtLeast(1)); val points=buckets.mapIndexed{ i,v -> androidx.compose.ui.geometry.Offset(i*step+step/2,size.height-(v/max)*(size.height-12f)) }; points.zipWithNext().forEach{(a,b)->drawLine(chartColor,a,b,strokeWidth=4f,cap=StrokeCap.Round)}; points.forEach{drawCircle(chartColor,4f,it)} } }
  StatLine("Завершённые тренировки",sessions.toString()); StatLine("Записанные приёмы пищи",meals.toString()); StatLine("Суммарные калории", "$kcal ккал"); StatLine("Белки по журналу", "${protein.toInt()} г"); StatLine("Отмеченные приёмы препаратов",doses.toString())
  Text("Экспорт отчёта",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("CSV" to "csv","XLSX" to "xlsx","PDF" to "pdf").forEach { (label,format)-> Button(onClick={exportFormat=format;launcher.launch("lukyanovsky-report.$format")},modifier=Modifier.weight(1f)){Text(label)} } }
  Text("Отчёт включает таблицы профиля, тренировок, питания, препаратов, блокнота и каталога продуктов. Для переноса приложения целиком используй ZIP-резервную копию.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
}
@Composable private fun StatLine(label:String,value:String){Card {Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label,modifier=Modifier.weight(1f));Text(value,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)}}}
@Composable private fun SmallNum(label:String,value:String,onValue:(String)->Unit,modifier:Modifier=Modifier){OutlinedTextField(value,onValue,modifier=modifier,label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))}


@Composable private fun FoodCatalogDialog(foods:List<FoodCatalogEntity>,onDismiss:()->Unit,onAdd:(FoodCatalogEntity,Double)->Unit){
 var query by remember { mutableStateOf("") }; var selected by remember { mutableStateOf<FoodCatalogEntity?>(null) }; var grams by remember { mutableStateOf("100") }
 val filtered=foods.filter { it.name.contains(query,true) || it.category.contains(query,true) }
 AlertDialog(onDismissRequest=onDismiss,title={Text("Каталог продуктов")},text={Column(Modifier.heightIn(max=480.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
  OutlinedTextField(query,{query=it},label={Text("Поиск продукта")},singleLine=true)
  if(selected==null) filtered.forEach { food -> TextButton(onClick={selected=food}) { Column(Modifier.fillMaxWidth()){Text(food.name);Text("${food.caloriesPer100g} ккал · Б ${food.proteinPer100g} · Ж ${food.fatPer100g} · У ${food.carbsPer100g} на 100 г",style=MaterialTheme.typography.bodySmall)} } }
  else { Text(selected!!.name,fontWeight=FontWeight.Bold); OutlinedTextField(grams,{grams=it},label={Text("Граммовка")},singleLine=true); val g=grams.toDoubleOrNull()?:0.0; val f=selected!!; Text("${(f.caloriesPer100g*g/100).toInt()} ккал · Б ${(f.proteinPer100g*g/100).toInt()} г · Ж ${(f.fatPer100g*g/100).toInt()} г · У ${(f.carbsPer100g*g/100).toInt()} г") }
 }},confirmButton={if(selected!=null) TextButton(enabled=(grams.toDoubleOrNull()?:0.0)>0,onClick={onAdd(selected!!,grams.toDouble())}){Text("Добавить в дневник")}},dismissButton={TextButton(onClick={if(selected!=null) selected=null else onDismiss()}){Text(if(selected!=null)"Назад" else "Закрыть")}})
}
