package com.lukyanovskykach.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

/** Stores profile and progress photos inside app-private storage. */
object ProfileMediaStore {
    private fun dir(context: Context) = File(context.filesDir, "progress_photos").apply { mkdirs() }
    fun profileFile(context: Context): File? = context.getSharedPreferences("profile_media", Context.MODE_PRIVATE)
        .getString("profile_photo", null)?.let(::File)?.takeIf { it.exists() }
    fun galleryFiles(context: Context): List<File> = context.getSharedPreferences("profile_media", Context.MODE_PRIVATE)
        .getStringSet("gallery", emptySet()).orEmpty().map(::File).filter { it.exists() }.sortedByDescending { it.lastModified() }
    fun setProfile(context: Context, file: File) { context.getSharedPreferences("profile_media", Context.MODE_PRIVATE).edit().putString("profile_photo", file.absolutePath).apply() }
    fun addGallery(context: Context, file: File) {
        val prefs = context.getSharedPreferences("profile_media", Context.MODE_PRIVATE)
        val values = prefs.getStringSet("gallery", emptySet()).orEmpty().toMutableSet()
        values.add(file.absolutePath); prefs.edit().putStringSet("gallery", values).apply()
    }
    fun clear(context: Context) { context.getSharedPreferences("profile_media", Context.MODE_PRIVATE).edit().clear().apply() }
    fun copyIn(context: Context, uri: Uri, gallery: Boolean): File {
        val file = File(dir(context), "${UUID.randomUUID()}.jpg")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Не удалось открыть изображение" }.use { stream -> file.outputStream().use { output -> stream.copyTo(output) } }
        }
        if (gallery) addGallery(context, file) else setProfile(context, file)
        return file
    }
    fun importProfile(context: Context, source: File) { val dest = File(dir(context), "profile_import.jpg"); source.copyTo(dest, true); setProfile(context, dest) }
    fun importGallery(context: Context, source: File) { val dest = File(dir(context), "${UUID.randomUUID()}.jpg"); source.copyTo(dest, true); addGallery(context, dest) }
    fun allFiles(context: Context): List<File> = listOfNotNull(profileFile(context)) + galleryFiles(context)
    fun clearGallery(context: Context) { context.getSharedPreferences("profile_media", Context.MODE_PRIVATE).edit().remove("gallery").apply() }
}
