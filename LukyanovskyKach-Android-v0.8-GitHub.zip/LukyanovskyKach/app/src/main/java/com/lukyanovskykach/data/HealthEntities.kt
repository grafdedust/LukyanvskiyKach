package com.lukyanovskykach.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "meal_entries", indices = [Index("eatenAt")])
data class MealEntryEntity(@PrimaryKey val id:String, val title:String, val mealType:String, val foodDescription:String, val calories:Int, val protein:Double, val fat:Double, val carbs:Double, val eatenAt:Long=System.currentTimeMillis(), val note:String?=null)

@Entity(tableName = "nutrition_goals")
data class NutritionGoalEntity(@PrimaryKey val id:Int=1, val calories:Int=2000, val protein:Double=120.0, val fat:Double=70.0, val carbs:Double=220.0, val updatedAt:Long=System.currentTimeMillis())

@Entity(tableName = "medications", indices = [Index("active")])
data class MedicationEntity(@PrimaryKey val id:String, val name:String, val dosage:String, val unit:String, val schedule:String, val startAt:Long=System.currentTimeMillis(), val endAt:Long?=null, val active:Boolean=true, val note:String?=null, val createdAt:Long=System.currentTimeMillis())

@Entity(tableName = "medication_logs", indices = [Index("medicationId"), Index("takenAt")])
data class MedicationLogEntity(@PrimaryKey val id:String, val medicationId:String, val medicationName:String, val dosage:String, val status:String, val scheduledAt:Long, val takenAt:Long?=null, val note:String?=null)
