package com.lukyanovskykach.ui.screens

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AppSettingsScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("kach_preferences", android.content.Context.MODE_PRIVATE) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "dark") ?: "dark") }
    var language by remember { mutableStateOf(prefs.getString("language", "system") ?: "system") }
    PageColumn {
        Text("Настройки приложения", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Оформление и язык интерфейса", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Тема оформления", fontWeight = FontWeight.SemiBold)
                listOf("dark" to "Тёмная", "light" to "Светлая", "system" to "Как в системе").forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label)
                        RadioButton(selected = theme == key, onClick = {
                            theme = key
                            prefs.edit().putString("theme", key).apply()
                            AppCompatDelegate.setDefaultNightMode(when (key) {
                                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                                "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                                else -> AppCompatDelegate.MODE_NIGHT_YES
                            })
                        })
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Язык", fontWeight = FontWeight.SemiBold)
                listOf("system" to "Язык системы", "ru" to "Русский", "uk" to "Українська").forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label)
                        RadioButton(selected = language == key, onClick = {
                            language = key
                            prefs.edit().putString("language", key).apply()
                            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(if (key == "system") "" else key))
                        })
                    }
                }
            }
        }
        Text("Настройки сохраняются на устройстве и применяются после выбора. Системный язык и тема используют параметры Android.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
