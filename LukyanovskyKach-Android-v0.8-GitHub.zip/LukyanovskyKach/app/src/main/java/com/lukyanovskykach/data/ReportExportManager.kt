package com.lukyanovskykach.data

import android.content.Context
import android.net.Uri
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Экспортирует табличные данные приложения. XLSX формируется как минимальный OpenXML workbook без сторонних тяжёлых библиотек. */
object ReportExportManager {
    private val tables = listOf("measurement_definitions", "measurement_values", "workout_programs", "program_exercises", "workout_sessions", "workout_sets", "meal_entries", "nutrition_goals", "medications", "medication_logs", "notes", "task_lists", "tasks", "food_catalog")
    suspend fun export(context: Context, uri: Uri, format: String) = withContext(Dispatchers.IO) {
        val db = KachDatabase.getInstance(context).openHelper.readableDatabase
        when (format.lowercase()) {
            "csv" -> context.contentResolver.openOutputStream(uri).use { out ->
                requireNotNull(out); out.bufferedWriter(Charsets.UTF_8).use { writer ->
                    writer.write("Лукьяновский Кач — отчёт\nТаблица,Данные\n")
                    tables.forEach { table ->
                        val exists = runCatching { db.query("SELECT * FROM `$table` LIMIT 0").close(); true }.getOrDefault(false)
                        if (exists) db.query("SELECT * FROM `$table`").use { c -> while (c.moveToNext()) {
                            val values = (0 until c.columnCount).joinToString("; ") { i -> if (c.isNull(i)) "" else c.getString(i).orEmpty().replace("\"", "\"\"") }
                            writer.write("\"$table\",\"$values\"\n")
                        } }
                    }
                }
            }
            "pdf" -> {
                val doc = PdfDocument(); val paint = Paint().apply { textSize = 10f }
                var pageNo = 1; var y = 42f; var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
                page.canvas.drawText("Лукьяновский Кач — экспорт данных", 32f, y, paint); y += 28f
                tables.forEach { table -> runCatching { db.query("SELECT * FROM `$table`").use { c ->
                    page.canvas.drawText("[$table]", 32f, y, paint); y += 16f
                    while (c.moveToNext()) {
                        val line = (0 until c.columnCount).joinToString(" | ") { i -> if (c.isNull(i)) "" else c.getString(i).orEmpty() }.take(100)
                        if (y > 810f) { doc.finishPage(page); pageNo++; page = doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create()); y=36f }
                        page.canvas.drawText(line, 32f, y, paint); y += 13f
                    }
                } } }
                doc.finishPage(page); context.contentResolver.openOutputStream(uri).use { requireNotNull(it); doc.writeTo(it) }; doc.close()
            }
            "xlsx" -> context.contentResolver.openOutputStream(uri).use { raw ->
                requireNotNull(raw); ZipOutputStream(raw).use { z ->
                    fun entry(name:String, content:String) { z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
                    entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
                    entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
                    entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Данные" sheetId="1" r:id="rId1"/></sheets></workbook>""")
                    entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
                    val rows = StringBuilder(); var row=1
                    fun cell(col:Int, value:String) = "<c r=\"${colName(col)}$row\" t=\"inlineStr\"><is><t>${xml(value)}</t></is></c>"
                    rows.append("<row r=\"$row\">${cell(1,"Таблица")}${cell(2,"Значения")}</row>"); row++
                    tables.forEach { table -> runCatching { db.query("SELECT * FROM `$table`").use { c -> while(c.moveToNext()) { val data=(0 until c.columnCount).joinToString(" | "){i->if(c.isNull(i)) "" else c.getString(i).orEmpty()}; rows.append("<row r=\"$row\">${cell(1,table)}${cell(2,data)}</row>"); row++ } } } }
                    entry("xl/worksheets/sheet1.xml", """<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$rows</sheetData></worksheet>""")
                }
            }
            else -> error("Неподдерживаемый формат")
        }
    }
    private fun colName(n:Int):String = if(n<=26) ('A'.code+n-1).toChar().toString() else "A${('A'.code+n-27).toChar()}"
    private fun xml(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
}
