package com.lukyanovskykach.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import java.util.concurrent.TimeUnit

class MedicationReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val name = inputData.getString("name") ?: "Напоминание"
        val dosage = inputData.getString("dosage") ?: ""
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("medication_reminders", "Напоминания", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(applicationContext, "medication_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Лукьяновский Кач · напоминание")
            .setContentText("$name ${dosage}".trim())
            .setAutoCancel(true).build()
        manager.notify(inputData.getString("id")?.hashCode() ?: name.hashCode(), notification)
        return Result.success()
    }
}

object MedicationReminderScheduler {
    fun schedule(context: Context, id: String, name: String, dosage: String, hour: Int, minute: Int) {
        val now = java.util.Calendar.getInstance()
        val next = (now.clone() as java.util.Calendar).apply { set(java.util.Calendar.HOUR_OF_DAY,hour); set(java.util.Calendar.MINUTE,minute); set(java.util.Calendar.SECOND,0); if(timeInMillis<=now.timeInMillis) add(java.util.Calendar.DAY_OF_YEAR,1) }
        val delay = (next.timeInMillis-now.timeInMillis).coerceAtLeast(1000)
        val data = workDataOf("id" to id, "name" to name, "dosage" to dosage)
        val request = PeriodicWorkRequestBuilder<MedicationReminderWorker>(24,TimeUnit.HOURS,15,TimeUnit.MINUTES).setInitialDelay(delay,TimeUnit.MILLISECONDS).setInputData(data).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("medication_$id",ExistingPeriodicWorkPolicy.UPDATE,request)
    }
    fun cancel(context: Context,id:String) { WorkManager.getInstance(context).cancelUniqueWork("medication_$id") }
}
