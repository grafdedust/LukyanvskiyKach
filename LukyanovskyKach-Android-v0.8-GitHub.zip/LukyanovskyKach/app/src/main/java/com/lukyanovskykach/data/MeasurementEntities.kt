package com.lukyanovskykach.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "measurement_definitions", indices = [Index("name", unique = true)])
data class MeasurementDefinitionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val unit: String = "см",
    val sideMode: String = "NONE", // NONE, LEFT_RIGHT, BOTH
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(
    tableName = "measurement_values",
    indices = [Index("definitionId"), Index("measuredAt")]
)
data class MeasurementValueEntity(
    @PrimaryKey val id: String,
    val definitionId: String,
    val value: Double,
    val side: String? = null, // LEFT, RIGHT, null
    val measuredAt: Long = System.currentTimeMillis(),
    val note: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)
