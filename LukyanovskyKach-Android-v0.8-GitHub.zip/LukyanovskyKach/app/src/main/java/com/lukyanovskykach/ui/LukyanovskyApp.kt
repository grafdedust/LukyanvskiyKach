package com.lukyanovskykach.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lukyanovskykach.R
import androidx.compose.ui.platform.LocalContext
import com.lukyanovskykach.data.KachDatabase
import com.lukyanovskykach.ui.screens.*

private data class Destination(
    val route: String,
    val label: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun LukyanovskyApp() {
    val nav = rememberNavController()
    val database = remember { KachDatabase.getInstance(LocalContext.current) }
    val destinations = listOf(
        Destination("home", R.string.tab_home, Icons.Default.Home),
        Destination("workouts", R.string.tab_workouts, Icons.Default.FitnessCenter),
        Destination("profile", R.string.tab_profile, Icons.Default.Person),
        Destination("nutrition", R.string.tab_nutrition, Icons.Default.Restaurant),
        Destination("more", R.string.tab_more, Icons.Default.MoreHoriz)
    )
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                destinations.forEach { item ->
                    NavigationBarItem(
                        selected = current == item.route,
                        onClick = {
                            nav.navigate(item.route) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(stringResource(item.label)) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { DashboardScreen(
                onStartWorkout = { nav.navigate("workouts") },
                onProfile = { nav.navigate("profile") }
            ) }
            composable("workouts") { WorkoutsScreen(database = database) }
            composable("profile") { ProfileScreen(database = database) }
            composable("nutrition") { NutritionScreen(database) }
            composable("more") { MoreScreen(
                onMedications = { nav.navigate("medications") },
                onStatistics = { nav.navigate("statistics") },
                onSettings = { nav.navigate("settings") },
                onNotebook = { nav.navigate("notebook") },
                onBackup = { nav.navigate("backup") }
            ) }
            composable("medications") { MedicationsScreen(database) }
            composable("statistics") { StatisticsScreen(database) }
            composable("settings") { AppSettingsScreen() }
            composable("backup") { BackupSettingsScreen() }
            composable("notebook") { NotebookScreen(database) }
        }
    }
}
