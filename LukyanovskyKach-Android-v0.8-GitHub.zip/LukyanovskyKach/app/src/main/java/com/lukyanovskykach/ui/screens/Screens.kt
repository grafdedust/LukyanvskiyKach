package com.lukyanovskykach.ui.screens

import androidx.compose.foundation.clickable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.clip
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import com.lukyanovskykach.data.ProfileMediaStore
import com.lukyanovskykach.data.BackupManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Pill
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.lukyanovskykach.R
import com.lukyanovskykach.data.KachDatabase
import com.lukyanovskykach.data.MeasurementDefinitionEntity
import com.lukyanovskykach.data.MeasurementValueEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        content = { item { Column(verticalArrangement = Arrangement.spacedBy(16.dp), content = content) } }
    )
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
}

@Composable
private fun MetricCard(title: String, value: String, note: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(note, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun DashboardScreen(onStartWorkout: () -> Unit, onProfile: () -> Unit) {
    PageColumn {
        Text("ЛУКЬЯНОВСКИЙ КАЧ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
        Text(stringResource(R.string.hello), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.current_weight), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("—", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(" кг", modifier = Modifier.padding(bottom = 8.dp))
                }
                Text("Добавьте первое измерение в профиле", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f)) { MetricCard(stringResource(R.string.workouts_week), "0", "за последние 7 дней") }
            Box(Modifier.weight(1f)) { MetricCard(stringResource(R.string.plan_completion), "—", "пока нет плана") }
        }
        SectionLabel(stringResource(R.string.quick_actions))
        Button(onClick = onStartWorkout, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FitnessCenter, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.start_workout))
        }
        OutlinedButton(onClick = onProfile, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.MonitorWeight, null)
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.add_measurement))
        }
        SectionLabel(stringResource(R.string.today_plan))
        InfoCard("План на сегодня", "Пока не создан")
        SectionLabel(stringResource(R.string.recent_activity))
        Text(stringResource(R.string.empty_state), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ProfileScreen(database: KachDatabase) {
    val dao = database.measurementDao()
    val definitions by dao.observeDefinitions().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selectedDefinition by remember { mutableStateOf<MeasurementDefinitionEntity?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var showAddValue by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (dao.definitionCount() == 0) {
            val defaults = listOf(
                "Вес" to "кг", "Рост" to "см", "Шея" to "см", "Плечи" to "см",
                "Грудь" to "см", "Талия" to "см", "Живот" to "см", "Бёдра" to "см",
                "Бицепс" to "см", "Предплечье" to "см", "Запястье" to "см",
                "Кисть" to "см", "Бедро" to "см", "Икра" to "см", "Голеностоп" to "см"
            )
            defaults.forEach { (name, unit) ->
                dao.upsertDefinition(
                    MeasurementDefinitionEntity(
                        id = UUID.randomUUID().toString(),
                        name = name,
                        unit = unit,
                        sideMode = if (name in listOf("Бицепс", "Предплечье", "Запястье", "Кисть", "Бедро", "Икра")) "LEFT_RIGHT" else "NONE",
                        isBuiltIn = true
                    )
                )
            }
        }
    }

    PageColumn {
        Text(stringResource(R.string.profile_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        ProfileMediaPanel()
        Text("История параметров сохраняется на этом устройстве", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.body_measurements), modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = { showCreate = true }) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.add_custom))
            }
        }
        if (definitions.isEmpty()) {
            Text("Подготавливаем список параметров…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            definitions.forEach { definition ->
                MeasurementDefinitionCard(
                    definition = definition,
                    onClick = { selectedDefinition = definition; showAddValue = true },
                    onHistory = { selectedDefinition = definition }
                )
            }
        }
        Text(
            "Нажмите на параметр, чтобы внести новое значение. Предыдущие замеры останутся в истории.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall
        )
    }

    if (showCreate) {
        CreateMeasurementDialog(
            onDismiss = { showCreate = false },
            onSave = { name, unit, sideMode ->
                scope.launch {
                    dao.upsertDefinition(
                        MeasurementDefinitionEntity(
                            id = UUID.randomUUID().toString(),
                            name = name.trim(),
                            unit = unit.trim().ifBlank { "см" },
                            sideMode = sideMode,
                            isBuiltIn = false
                        )
                    )
                }
                showCreate = false
            }
        )
    }

    if (showAddValue && selectedDefinition != null) {
        AddMeasurementValueDialog(
            definition = selectedDefinition!!,
            onDismiss = { showAddValue = false },
            onSave = { value, side, note ->
                scope.launch {
                    dao.upsertValue(
                        MeasurementValueEntity(
                            id = UUID.randomUUID().toString(),
                            definitionId = selectedDefinition!!.id,
                            value = value,
                            side = side,
                            note = note.ifBlank { null }
                        )
                    )
                }
                showAddValue = false
            }
        )
    }

    selectedDefinition?.let { definition ->
        if (!showAddValue) {
            MeasurementHistoryDialog(
                database = database,
                definition = definition,
                onDismiss = { selectedDefinition = null },
                onAdd = { showAddValue = true }
            )
        }
    }
}

@Composable
private fun MeasurementDefinitionCard(
    definition: MeasurementDefinitionEntity,
    onClick: () -> Unit,
    onHistory: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(definition.name, fontWeight = FontWeight.SemiBold)
                Text(
                    if (definition.sideMode == "LEFT_RIGHT") "Можно записывать левую и правую стороны · ${definition.unit}" else "Единица: ${definition.unit}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            TextButton(onClick = onHistory) { Text("История") }
            Icon(Icons.Default.Add, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun CreateMeasurementDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("см") }
    var sideMode by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый параметр") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название, например «Размер кисти»") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("Единица измерения") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = sideMode, onCheckedChange = { sideMode = it })
                    Text("Отдельно левая и правая сторона")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onSave(name, unit, if (sideMode) "LEFT_RIGHT" else "NONE") }, enabled = name.isNotBlank()) {
                Text("Создать")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun AddMeasurementValueDialog(
    definition: MeasurementDefinitionEntity,
    onDismiss: () -> Unit,
    onSave: (Double, String?, String) -> Unit
) {
    var value by remember { mutableStateOf("") }
    var side by remember { mutableStateOf("NONE") }
    var note by remember { mutableStateOf("") }
    val number = value.replace(',', '.').toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый замер: ${definition.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Значение (${definition.unit})") },
                    singleLine = true
                )
                if (definition.sideMode == "LEFT_RIGHT") {
                    Text("Сторона", style = MaterialTheme.typography.labelMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selected = side == "LEFT", onClick = { side = "LEFT" }, label = { Text("Левая") })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = side == "RIGHT", onClick = { side = "RIGHT" }, label = { Text("Правая") })
                        Spacer(Modifier.width(8.dp))
                        FilterChip(selected = side == "NONE", onClick = { side = "NONE" }, label = { Text("Общий") })
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Заметка (необязательно)") })
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (number != null && number > 0) onSave(number, side.takeIf { it != "NONE" }, note) },
                enabled = number != null && number > 0
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun MeasurementHistoryDialog(
    database: KachDatabase,
    definition: MeasurementDefinitionEntity,
    onDismiss: () -> Unit,
    onAdd: () -> Unit
) {
    val values by database.measurementDao().observeValues(definition.id).collectAsState(initial = emptyList())
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("История: ${definition.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (values.isEmpty()) {
                    Text("Пока нет записей. Добавьте первый замер.")
                } else {
                    values.forEach { item ->
                        val sideLabel = when (item.side) {
                            "LEFT" -> " · левая"
                            "RIGHT" -> " · правая"
                            else -> ""
                        }
                        Column {
                            Text("${item.value} ${definition.unit}$sideLabel", fontWeight = FontWeight.SemiBold)
                            Text(dateFormat.format(Date(item.measuredAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            if (!item.note.isNullOrBlank()) Text(item.note!!, style = MaterialTheme.typography.bodySmall)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onAdd) { Text("Добавить замер") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}


@Composable
fun NutritionScreen() {
    PageColumn {
        Text(stringResource(R.string.nutrition_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        MetricCard("Цель на день", "Не задана", "настройте план питания")
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить приём пищи") }
        InfoCard("Завтрак", "Пока нет записей")
        InfoCard("Обед", "Пока нет записей")
        InfoCard("Ужин", "Пока нет записей")
    }
}

@Composable
fun MoreScreen(onMedications: () -> Unit, onStatistics: () -> Unit, onSettings: () -> Unit, onNotebook: () -> Unit, onBackup: () -> Unit) {
    PageColumn {
        Text("Ещё", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        MenuRow("Блокнот и задачи", onNotebook) { Icon(Icons.Default.Description, null) }
        MenuRow("Препараты и добавки", onMedications) { Icon(Icons.Default.Pill, null) }
        MenuRow("Статистика и экспорт", onStatistics) { Icon(Icons.Default.QueryStats, null) }
        MenuRow("Настройки приложения", onSettings) { Icon(Icons.Default.Settings, null) }
        MenuRow("Резервные копии", onBackup) { Icon(Icons.Default.Settings, null) }
    }
}

@Composable
fun SimpleSectionScreen(titleRes: Int) {
    PageColumn {
        Text(stringResource(titleRes), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.empty_state), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(stringResource(R.string.prototype_note), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun InfoCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MenuRow(title: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(12.dp))
            Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


@Composable
private fun PhotoThumb(file: File, modifier: Modifier = Modifier) {
    val bitmap = remember(file.absolutePath, file.lastModified()) { BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap() }
    if (bitmap != null) Image(bitmap, contentDescription = "Фото прогресса", modifier = modifier)
}

@Composable
fun ProfileMediaPanel() {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val profile = remember(refresh) { ProfileMediaStore.profileFile(context) }
    val gallery = remember(refresh) { ProfileMediaStore.galleryFiles(context) }
    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { runCatching { ProfileMediaStore.copyIn(context, it, false) }.onSuccess { refresh++ } }
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { uri -> runCatching { ProfileMediaStore.copyIn(context, uri, true) } }; refresh++
    }
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (profile != null) PhotoThumb(profile, Modifier.size(76.dp).clip(CircleShape))
                else Surface(Modifier.size(76.dp), shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                    Box(contentAlignment = Alignment.Center) { Text("ФОТО", style = MaterialTheme.typography.labelSmall) }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Фото профиля", fontWeight = FontWeight.SemiBold)
                    Text("Аватар и личная фотохроника изменений", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { profilePicker.launch("image/*") }) { Text(if (profile == null) "Добавить фото" else "Изменить фото") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Галерея прогресса · ${gallery.size}", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                FilledTonalButton(onClick = { galleryPicker.launch("image/*") }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Добавить") }
            }
            if (gallery.isEmpty()) Text("Добавляйте фотографии в динамике, чтобы сравнивать изменения.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                gallery.take(4).forEach { file -> PhotoThumb(file, Modifier.size(68.dp)) }
                if (gallery.size > 4) Text("+${gallery.size - 4}", modifier = Modifier.align(Alignment.CenterVertically))
            }
        }
    }
}

@Composable
fun BackupSettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmImport by remember { mutableStateOf<Uri?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            busy = true
            runCatching { BackupManager.export(context, uri) }
                .onSuccess { message = "Резервная копия создана. Сохраните ZIP на новом телефоне или в облаке." }
                .onFailure { message = "Ошибка экспорта: ${it.message}" }
            busy = false
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) confirmImport = uri }
    PageColumn {
        Text("Резервная копия", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Переносите приложение на другой телефон вместе с базой данных и фотографиями.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Экспорт всей базы", fontWeight = FontWeight.SemiBold)
                Text("В ZIP попадут замеры, программы и история тренировок, а также фото профиля и галерея прогресса.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = { exportLauncher.launch("lukyanovsky-kach-backup.zip") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Создать ZIP-копию")
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Импорт на новом телефоне", fontWeight = FontWeight.SemiBold)
                Text("Выберите ZIP, созданный этим приложением. Текущая локальная база будет заменена данными из архива.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Восстановить из ZIP")
                }
            }
        }
        if (busy) CircularProgressIndicator()
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        Text("Совет: после экспорта отправьте ZIP себе в облако или сохраните на отдельный носитель. Файл содержит личные данные и фотографии.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    confirmImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmImport = null },
            title = { Text("Заменить текущие данные?") },
            text = { Text("Импорт заменит базу данных на содержимое архива. Перед продолжением рекомендуется экспортировать текущую копию.") },
            confirmButton = { TextButton(onClick = {
                confirmImport = null
                scope.launch {
                    busy = true
                    runCatching { BackupManager.import(context, uri) }
                        .onSuccess { message = "Импорт завершён. Данные и фотографии восстановлены." }
                        .onFailure { message = "Ошибка импорта: ${it.message}" }
                    busy = false
                }
            }) { Text("Заменить данные") } },
            dismissButton = { TextButton(onClick = { confirmImport = null }) { Text("Отмена") } }
        )
    }
}
