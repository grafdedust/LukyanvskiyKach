package com.lukyanovskykach.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {
    @Query("SELECT * FROM workout_programs WHERE deletedAt IS NULL ORDER BY updatedAt DESC")
    fun observePrograms(): Flow<List<WorkoutProgramEntity>>
    @Query("SELECT * FROM program_exercises WHERE programId = :programId AND deletedAt IS NULL ORDER BY orderIndex, createdAt")
    fun observeExercises(programId: String): Flow<List<ProgramExerciseEntity>>
    @Query("SELECT * FROM program_exercises WHERE programId = :programId AND deletedAt IS NULL ORDER BY orderIndex, createdAt")
    suspend fun getExercises(programId: String): List<ProgramExerciseEntity>
    @Query("SELECT * FROM workout_sessions ORDER BY startedAt DESC")
    fun observeSessions(): Flow<List<WorkoutSessionEntity>>
    @Query("SELECT * FROM workout_sessions WHERE status = 'ACTIVE' ORDER BY startedAt DESC LIMIT 1")
    fun observeActiveSession(): Flow<WorkoutSessionEntity?>
    @Query("SELECT * FROM workout_sets WHERE sessionId = :sessionId ORDER BY exerciseName, setNumber")
    fun observeSessionSets(sessionId: String): Flow<List<WorkoutSetEntity>>
    @Query("SELECT * FROM workout_sets WHERE sessionId = :sessionId ORDER BY exerciseName, setNumber")
    suspend fun getSessionSets(sessionId: String): List<WorkoutSetEntity>
    @Query("SELECT * FROM workout_sets WHERE completed = 1 ORDER BY weightKg DESC, actualReps DESC")
    fun observePersonalRecords(): Flow<List<WorkoutSetEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveProgram(item: WorkoutProgramEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveExercise(item: ProgramExerciseEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveSession(item: WorkoutSessionEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveSet(item: WorkoutSetEntity)
    @Query("UPDATE program_exercises SET deletedAt = :now, updatedAt = :now WHERE id = :id") suspend fun deleteExercise(id: String, now: Long = System.currentTimeMillis())
    @Query("UPDATE workout_sessions SET status = :status, finishedAt = :finishedAt WHERE id = :id") suspend fun finishSession(id: String, status: String, finishedAt: Long)
    @Query("SELECT COUNT(*) FROM workout_sessions WHERE status = 'COMPLETED' AND startedAt >= :since") suspend fun completedSince(since: Long): Int
}
