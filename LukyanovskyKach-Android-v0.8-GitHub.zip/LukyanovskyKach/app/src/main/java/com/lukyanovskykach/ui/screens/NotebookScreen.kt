package com.lukyanovskykach.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.lukyanovskykach.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun NotebookScreen(database: KachDatabase) {
    val dao = database.notebookDao()
    val notes by dao.observeNotes().collectAsState(initial = emptyList())
    val lists by dao.observeLists().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var editNote by remember { mutableStateOf<NoteEntity?>(null) }
    var createList by remember { mutableStateOf(false) }
    var selectedList by remember { mutableStateOf<TaskListEntity?>(null) }

    PageColumn {
        Text("Блокнот", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Записи, планы и списки. Всё хранится на устройстве.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Заметки") }, icon = { Icon(Icons.Default.Description, null) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Задачи") }, icon = { Icon(Icons.Default.ListAlt, null) })
        }
        if (tab == 0) {
            Button(onClick = { editNote = NoteEntity(UUID.randomUUID().toString(), "", "") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Новая заметка")
            }
            if (notes.isEmpty()) Text("Заметок пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
            notes.forEach { note ->
                Card(onClick = { editNote = note }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(note.title.ifBlank { "Без названия" }, fontWeight = FontWeight.SemiBold)
                        Text(note.body, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(note.updatedAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            Button(onClick = { createList = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Создать список") }
            if (lists.isEmpty()) Text("Например: покупки, дела на неделю или список вещей", color = MaterialTheme.colorScheme.onSurfaceVariant)
            lists.forEach { list ->
                Card(onClick = { selectedList = list }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(list.title, fontWeight = FontWeight.SemiBold); Text("Открыть задачи", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
    editNote?.let { note ->
        var title by remember(note.id) { mutableStateOf(note.title) }
        var body by remember(note.id) { mutableStateOf(note.body) }
        AlertDialog(onDismissRequest = { editNote = null }, title = { Text(if (note.title.isBlank() && note.body.isBlank()) "Новая заметка" else "Заметка") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Заголовок") }, singleLine = true)
                OutlinedTextField(body, { body = it }, label = { Text("Текст") }, minLines = 5)
            } },
            confirmButton = { TextButton(onClick = { scope.launch { dao.saveNote(note.copy(title = title, body = body, updatedAt = System.currentTimeMillis())) }; editNote = null }) { Text("Сохранить") } },
            dismissButton = { Row { if (note.createdAt != note.updatedAt || note.title.isNotBlank() || note.body.isNotBlank()) TextButton(onClick = { scope.launch { dao.deleteNote(note.id, System.currentTimeMillis()) }; editNote = null }) { Text("Удалить") }; TextButton(onClick = { editNote = null }) { Text("Отмена") } } }
        )
    }
    if (createList) {
        var title by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { createList = false }, title = { Text("Новый список") },
            text = { OutlinedTextField(title, { title = it }, label = { Text("Например, покупки") }, singleLine = true) },
            confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { scope.launch { dao.saveList(TaskListEntity(UUID.randomUUID().toString(), title.trim())) }; createList = false }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { createList = false }) { Text("Отмена") } })
    }
    selectedList?.let { list -> TaskListDialog(list, dao, { selectedList = null }) }
}

@Composable
private fun TaskListDialog(list: TaskListEntity, dao: NotebookDao, onDismiss: () -> Unit) {
    val tasks by dao.observeTasks(list.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var newTask by remember(list.id) { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(list.title) },
        text = { Column(Modifier.heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(newTask, { newTask = it }, modifier = Modifier.weight(1f), label = { Text("Новая задача") }, singleLine = true)
                IconButton(onClick = { if (newTask.isNotBlank()) { scope.launch { dao.saveTask(TaskEntity(UUID.randomUUID().toString(), list.id, newTask.trim(), position = tasks.size)) }; newTask = "" } }) { Icon(Icons.Default.Add, "Добавить") }
            }
            LazyColumn { items(tasks, key = { it.id }) { task ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(checked = task.isCompleted, onCheckedChange = { done -> scope.launch { dao.setTaskCompleted(task.id, done, if (done) System.currentTimeMillis() else null, System.currentTimeMillis()) } })
                    Text(task.title, modifier = Modifier.weight(1f), textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None, color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                    IconButton(onClick = { scope.launch { dao.deleteTask(task.id, System.currentTimeMillis()) } }) { Text("×") }
                }
            } }
            Text("Выполнено: ${tasks.count { it.isCompleted }} из ${tasks.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        } },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } },
        dismissButton = { TextButton(onClick = { scope.launch { dao.deleteList(list.id, System.currentTimeMillis()) }; onDismiss() }) { Text("Удалить список") } })
}
