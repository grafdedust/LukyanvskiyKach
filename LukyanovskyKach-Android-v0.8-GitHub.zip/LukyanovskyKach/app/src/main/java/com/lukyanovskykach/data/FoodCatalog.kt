package com.lukyanovskykach.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface FoodCatalogDao {
    @Query("SELECT * FROM food_catalog ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<FoodCatalogEntity>>
    @Query("SELECT * FROM food_catalog WHERE name LIKE '%' || :query || '%' ORDER BY name LIMIT 50") fun search(query: String): Flow<List<FoodCatalogEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(food: FoodCatalogEntity)
    @Delete suspend fun delete(food: FoodCatalogEntity)
    @Query("SELECT COUNT(*) FROM food_catalog") suspend fun count(): Int
}

object FoodCatalogSeeder {
    suspend fun seed(dao: FoodCatalogDao) {
        if (dao.count() > 0) return
        val foods = listOf(
            FoodCatalogEntity("food_oats", "Овсяные хлопья (сухие)", 366, 12.3, 6.1,  66.3, "Крупы"),
            FoodCatalogEntity("food_rice", "Рис белый (сухой)",   365, 7.0, 0.7, 78.0, "Крупы"),
            FoodCatalogEntity("food_chicken", "Куриная грудка", 120, 23.1, 2.6, 0.0, "Мясо"),
            FoodCatalogEntity("food_egg", "Яйцо куриное", 157, 12.7, 10.9, 0.7, "Яйца"),
            FoodCatalogEntity("food_buckwheat", "Гречка (сухая)", 343, 13.3, 3.4, 71.5, "Крупы"),
            FoodCatalogEntity("food_banana", "Банан", 89, 1.1, 0.3, 22.8, "Фрукты"),
            FoodCatalogEntity("food_cottage", "Творог 5%", 121, 17.2, 5.0, 1.8, "Молочные"),
            FoodCatalogEntity("food_tuna", "Тунец в собственном соку", 116, 25.5, 0.8, 0.0, "Рыба"),
            FoodCatalogEntity("food_potato", "Картофель", 77, 2.0, 0.1, 17.0, "Овощи"),
            FoodCatalogEntity("food_bread", "Хлеб пшеничный", 265, 9.0, 3.2, 49.0, "Хлеб"),
            FoodCatalogEntity("food_yogurt", "Йогурт натуральный", 63, 5.0, 3.5, 4.7, "Молочные"),
            FoodCatalogEntity("food_salmon", "Лосось", 208, 20.4, 13.4, 0.0, "Рыба")
        )
        foods.forEach { dao.save(it) }
    }
}
