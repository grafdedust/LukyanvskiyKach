package com.lukyanovskykach.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MeasurementDefinitionEntity::class, MeasurementValueEntity::class, WorkoutProgramEntity::class, ProgramExerciseEntity::class, WorkoutSessionEntity::class, WorkoutSetEntity::class, NoteEntity::class, TaskListEntity::class, TaskEntity::class, MealEntryEntity::class, NutritionGoalEntity::class, MedicationEntity::class, MedicationLogEntity::class, FoodCatalogEntity::class],
    version = 5,
    exportSchema = false
)
abstract class KachDatabase : RoomDatabase() {
    abstract fun measurementDao(): MeasurementDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun notebookDao(): NotebookDao
    abstract fun healthDao(): HealthDao
    abstract fun foodCatalogDao(): FoodCatalogDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS workout_programs (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, notes TEXT, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, deletedAt INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_programs_updatedAt ON workout_programs(updatedAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS program_exercises (id TEXT NOT NULL PRIMARY KEY, programId TEXT NOT NULL, name TEXT NOT NULL, sets INTEGER NOT NULL, reps INTEGER NOT NULL, weightKg REAL NOT NULL, restSeconds INTEGER NOT NULL, orderIndex INTEGER NOT NULL, notes TEXT, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, deletedAt INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_program_exercises_programId ON program_exercises(programId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_program_exercises_orderIndex ON program_exercises(orderIndex)")
                db.execSQL("CREATE TABLE IF NOT EXISTS workout_sessions (id TEXT NOT NULL PRIMARY KEY, programId TEXT, programName TEXT NOT NULL, startedAt INTEGER NOT NULL, finishedAt INTEGER, status TEXT NOT NULL, notes TEXT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sessions_programId ON workout_sessions(programId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sessions_startedAt ON workout_sessions(startedAt)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sessions_status ON workout_sessions(status)")
                db.execSQL("CREATE TABLE IF NOT EXISTS workout_sets (id TEXT NOT NULL PRIMARY KEY, sessionId TEXT NOT NULL, exerciseId TEXT, exerciseName TEXT NOT NULL, setNumber INTEGER NOT NULL, targetReps INTEGER NOT NULL, actualReps INTEGER NOT NULL, weightKg REAL NOT NULL, completed INTEGER NOT NULL, completedAt INTEGER, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sets_sessionId ON workout_sets(sessionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sets_exerciseId ON workout_sets(exerciseId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_workout_sets_completedAt ON workout_sets(completedAt)")
            }
        }
        private val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS notes (id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, deletedAt INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_notes_updatedAt ON notes(updatedAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS task_lists (id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, deletedAt INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_task_lists_updatedAt ON task_lists(updatedAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS tasks (id TEXT NOT NULL PRIMARY KEY, listId TEXT NOT NULL, title TEXT NOT NULL, isCompleted INTEGER NOT NULL, position INTEGER NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL, completedAt INTEGER, deletedAt INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tasks_listId ON tasks(listId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tasks_updatedAt ON tasks(updatedAt)")
            }
        }
        private val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS meal_entries (id TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, mealType TEXT NOT NULL, foodDescription TEXT NOT NULL, calories INTEGER NOT NULL, protein REAL NOT NULL, fat REAL NOT NULL, carbs REAL NOT NULL, eatenAt INTEGER NOT NULL, note TEXT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_meal_entries_eatenAt ON meal_entries(eatenAt)")
                db.execSQL("CREATE TABLE IF NOT EXISTS nutrition_goals (id INTEGER NOT NULL PRIMARY KEY, calories INTEGER NOT NULL, protein REAL NOT NULL, fat REAL NOT NULL, carbs REAL NOT NULL, updatedAt INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS medications (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, dosage TEXT NOT NULL, unit TEXT NOT NULL, schedule TEXT NOT NULL, startAt INTEGER NOT NULL, endAt INTEGER, active INTEGER NOT NULL, note TEXT, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_medications_active ON medications(active)")
                db.execSQL("CREATE TABLE IF NOT EXISTS medication_logs (id TEXT NOT NULL PRIMARY KEY, medicationId TEXT NOT NULL, medicationName TEXT NOT NULL, dosage TEXT NOT NULL, status TEXT NOT NULL, scheduledAt INTEGER NOT NULL, takenAt INTEGER, note TEXT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_medication_logs_medicationId ON medication_logs(medicationId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_medication_logs_takenAt ON medication_logs(takenAt)")
            }
        }
        private val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS food_catalog (id TEXT NOT NULL PRIMARY KEY, name TEXT NOT NULL, caloriesPer100g INTEGER NOT NULL, proteinPer100g REAL NOT NULL, fatPer100g REAL NOT NULL, carbsPer100g REAL NOT NULL, category TEXT NOT NULL, isCustom INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_food_catalog_name ON food_catalog(name)")
            }
        }
        @Volatile private var INSTANCE: KachDatabase? = null

        @Synchronized fun closeForRestore() {
            INSTANCE?.close()
            INSTANCE = null
        }

        fun getInstance(context: Context): KachDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KachDatabase::class.java,
                    "lukyanovsky-kach.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5).build().also { INSTANCE = it }
            }
    }
}
