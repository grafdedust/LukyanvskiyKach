package com.lukyanovskykach.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface HealthDao {
 @Query("SELECT * FROM meal_entries ORDER BY eatenAt DESC") fun observeMeals():Flow<List<MealEntryEntity>>
 @Query("SELECT * FROM meal_entries WHERE eatenAt BETWEEN :from AND :to ORDER BY eatenAt DESC") fun mealsBetween(from:Long,to:Long):Flow<List<MealEntryEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveMeal(item:MealEntryEntity)
 @Query("DELETE FROM meal_entries WHERE id=:id") suspend fun deleteMeal(id:String)
 @Query("SELECT * FROM nutrition_goals WHERE id=1") fun observeGoal():Flow<NutritionGoalEntity?>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveGoal(item:NutritionGoalEntity)
 @Query("SELECT * FROM medications WHERE active=1 ORDER BY name") fun observeMedications():Flow<List<MedicationEntity>>
 @Query("SELECT * FROM medications ORDER BY createdAt DESC") fun observeAllMedications():Flow<List<MedicationEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveMedication(item:MedicationEntity)
 @Query("UPDATE medications SET active=0 WHERE id=:id") suspend fun archiveMedication(id:String)
 @Query("SELECT * FROM medication_logs ORDER BY scheduledAt DESC") fun observeMedicationLogs():Flow<List<MedicationLogEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveMedicationLog(item:MedicationLogEntity)
 @Query("SELECT COUNT(*) FROM meal_entries WHERE eatenAt BETWEEN :from AND :to") fun mealCount(from:Long,to:Long):Flow<Int>
 @Query("SELECT COALESCE(SUM(calories),0) FROM meal_entries WHERE eatenAt BETWEEN :from AND :to") fun caloriesSum(from:Long,to:Long):Flow<Int>
 @Query("SELECT COALESCE(SUM(protein),0) FROM meal_entries WHERE eatenAt BETWEEN :from AND :to") fun proteinSum(from:Long,to:Long):Flow<Double>
 @Query("SELECT COUNT(*) FROM workout_sessions WHERE status='COMPLETED' AND startedAt BETWEEN :from AND :to") fun workoutCount(from:Long,to:Long):Flow<Int>
 @Query("SELECT COUNT(*) FROM medication_logs WHERE status='TAKEN' AND scheduledAt BETWEEN :from AND :to") fun dosesTaken(from:Long,to:Long):Flow<Int>
}
