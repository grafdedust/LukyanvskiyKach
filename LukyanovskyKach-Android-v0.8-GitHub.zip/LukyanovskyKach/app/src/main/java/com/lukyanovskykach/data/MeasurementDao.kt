package com.lukyanovskykach.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM measurement_definitions WHERE deletedAt IS NULL ORDER BY isBuiltIn DESC, name COLLATE NOCASE")
    fun observeDefinitions(): Flow<List<MeasurementDefinitionEntity>>

    @Query("SELECT * FROM measurement_values WHERE definitionId = :definitionId AND deletedAt IS NULL ORDER BY measuredAt DESC")
    fun observeValues(definitionId: String): Flow<List<MeasurementValueEntity>>

    @Query("SELECT * FROM measurement_values WHERE deletedAt IS NULL ORDER BY measuredAt DESC")
    fun observeAllValues(): Flow<List<MeasurementValueEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDefinition(item: MeasurementDefinitionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertValue(item: MeasurementValueEntity)

    @Query("SELECT COUNT(*) FROM measurement_definitions WHERE deletedAt IS NULL")
    suspend fun definitionCount(): Int

    @Query("UPDATE measurement_definitions SET deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id AND isBuiltIn = 0")
    suspend fun softDeleteDefinition(id: String, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE measurement_values SET deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
    suspend fun softDeleteValue(id: String, deletedAt: Long = System.currentTimeMillis())
}
