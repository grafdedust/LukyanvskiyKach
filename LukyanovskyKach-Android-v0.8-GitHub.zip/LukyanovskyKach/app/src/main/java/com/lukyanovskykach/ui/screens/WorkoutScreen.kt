package com.lukyanovskykach.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.lukyanovskykach.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Composable
fun WorkoutsScreen(database: KachDatabase) {
    val dao = database.workoutDao()
    val programs by dao.observePrograms().collectAsState(initial = emptyList())
    val sessions by dao.observeSessions().collectAsState(initial = emptyList())
    val active by dao.observeActiveSession().collectAsState(initial = null)
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<WorkoutProgramEntity?>(null) }
    var showProgram by remember { mutableStateOf(false) }
    var showExercise by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("programs") }
    val dateFmt = remember { SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()) }

    PageColumn {
        Text("Тренировки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        if (active != null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Тренировка продолжается", fontWeight = FontWeight.Bold)
                    Text(active!!.programName)
                    Button(onClick = { tab = "active" }, modifier = Modifier.fillMaxWidth()) { Text("Вернуться к тренировке") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == "programs", onClick = { tab = "programs" }, label = { Text("Программы") })
            FilterChip(selected = tab == "history", onClick = { tab = "history" }, label = { Text("История") })
            FilterChip(selected = tab == "records", onClick = { tab = "records" }, label = { Text("Рекорды") })
            if (active != null) FilterChip(selected = tab == "active", onClick = { tab = "active" }, label = { Text("Сейчас") })
        }
        when (tab) {
            "programs" -> {
                Button(onClick = { showProgram = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Создать программу") }
                if (programs.isEmpty()) Text("Пока нет программ. Создайте первую и добавьте упражнения.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                programs.forEach { program ->
                    val exercises by dao.observeExercises(program.id).collectAsState(initial = emptyList())
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(program.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${exercises.size} упражн.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            exercises.forEach { ex -> Text("• ${ex.name}: ${ex.sets} × ${ex.reps} · ${ex.weightKg} кг", style = MaterialTheme.typography.bodySmall) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { selected = program; showExercise = true }, modifier = Modifier.weight(1f)) { Text("Добавить упражнение") }
                                Button(onClick = { scope.launch { startWorkout(dao, program) }; tab = "active" }, enabled = exercises.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Начать") }
                            }
                        }
                    }
                }
            }
            "active" -> {
                if (active == null) Text("Активной тренировки нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else ActiveWorkoutPanel(dao, active!!, dateFmt)
            }
            "history" -> {
                if (sessions.filter { it.status != "ACTIVE" }.isEmpty()) Text("Завершённых тренировок пока нет", color = MaterialTheme.colorScheme.onSurfaceVariant)
                sessions.filter { it.status != "ACTIVE" }.forEach { session ->
                    val sets by dao.observeSessionSets(session.id).collectAsState(initial = emptyList())
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(session.programName, fontWeight = FontWeight.Bold)
                            Text(dateFmt.format(Date(session.startedAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${sets.count { it.completed }} из ${sets.size} подходов выполнено · ${sets.filter { it.completed }.sumOf { it.weightKg * it.actualReps }.toInt()} кг объём")
                            if (session.status == "ABANDONED") Text("Прервана", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            "records" -> PersonalRecordsPanel(dao)
        }
    }

    if (showProgram) TextEntryDialog("Новая программа", "Например, Грудь и трицепс", "Создать", { showProgram = false }) { name ->
        scope.launch { dao.saveProgram(WorkoutProgramEntity(UUID.randomUUID().toString(), name.trim())) }
        showProgram = false
    }
    if (showExercise && selected != null) ExerciseDialog(selected!!.id, dao, onDismiss = { showExercise = false }) { showExercise = false }
}

private suspend fun startWorkout(dao: WorkoutDao, program: WorkoutProgramEntity) {
    val exercises = dao.getExercises(program.id)
    val sessionId = UUID.randomUUID().toString()
    dao.saveSession(WorkoutSessionEntity(sessionId, program.id, program.name))
    exercises.forEach { exercise ->
        repeat(exercise.sets.coerceIn(1, 30)) { index ->
            dao.saveSet(WorkoutSetEntity(UUID.randomUUID().toString(), sessionId, exercise.id, exercise.name, index + 1, exercise.reps, exercise.reps, exercise.weightKg))
        }
    }
}

@Composable
private fun ExerciseDialog(programId: String, dao: WorkoutDao, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }; var sets by remember { mutableStateOf("3") }; var reps by remember { mutableStateOf("10") }; var weight by remember { mutableStateOf("0") }; var rest by remember { mutableStateOf("90") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Добавить упражнение") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Упражнение") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Подходы", sets, { sets = it }, Modifier.weight(1f))
                NumberField("Повторения", reps, { reps = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Вес, кг", weight, { weight = it }, Modifier.weight(1f), decimal = true)
                NumberField("Отдых, сек", rest, { rest = it }, Modifier.weight(1f))
            }
        }
    }, confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = {
        scope.launch { dao.saveExercise(ProgramExerciseEntity(UUID.randomUUID().toString(), programId, name.trim(), sets.toIntOrNull()?.coerceIn(1,30) ?: 3, reps.toIntOrNull()?.coerceAtLeast(1) ?: 10, weight.replace(',', '.').toDoubleOrNull() ?: 0.0, rest.toIntOrNull()?.coerceAtLeast(0) ?: 90, dao.getExercises(programId).size)); onSaved() }
    }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun ActiveWorkoutPanel(dao: WorkoutDao, session: WorkoutSessionEntity, dateFmt: SimpleDateFormat) {
    val sets by dao.observeSessionSets(session.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<WorkoutSetEntity?>(null) }
    val grouped = sets.groupBy { it.exerciseName }
    Text(session.programName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("Начало: ${dateFmt.format(Date(session.startedAt))}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    LinearProgressIndicator(progress = if (sets.isEmpty()) 0f else sets.count { it.completed }.toFloat() / sets.size, modifier = Modifier.fillMaxWidth())
    Text("Выполнено ${sets.count { it.completed }} / ${sets.size} подходов")
    grouped.forEach { (exercise, exerciseSets) ->
        Text(exercise, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        exerciseSets.forEach { set ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth().clickable { editing = set }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = set.completed, onCheckedChange = { checked -> scope.launch { dao.saveSet(set.copy(completed = checked, completedAt = if (checked) System.currentTimeMillis() else null, actualReps = if (checked && set.actualReps == 0) set.targetReps else set.actualReps)) } })
                    Column(Modifier.weight(1f)) { Text("Подход ${set.setNumber}: ${set.actualReps}/${set.targetReps} повт."); Text("${set.weightKg} кг", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
                    if (set.completed) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = { editing = set }) { Text("Изменить") }
                }
            }
        }
    }
    Button(onClick = { scope.launch { dao.finishSession(session.id, "COMPLETED", System.currentTimeMillis()) } }, enabled = sets.isNotEmpty() && sets.all { it.completed }, modifier = Modifier.fillMaxWidth()) { Text("Завершить тренировку") }
    OutlinedButton(onClick = { scope.launch { dao.finishSession(session.id, "ABANDONED", System.currentTimeMillis()) } }, modifier = Modifier.fillMaxWidth()) { Text("Прервать тренировку") }
    editing?.let { set -> EditSetDialog(set, onDismiss = { editing = null }) { reps, weight -> scope.launch { dao.saveSet(set.copy(actualReps = reps, weightKg = weight, completedAt = if (set.completed) System.currentTimeMillis() else set.completedAt)) }; editing = null } }
}

@Composable
private fun EditSetDialog(set: WorkoutSetEntity, onDismiss: () -> Unit, onSave: (Int, Double) -> Unit) {
    var reps by remember(set.id) { mutableStateOf(set.actualReps.toString()) }; var weight by remember(set.id) { mutableStateOf(set.weightKg.toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Подход ${set.setNumber}") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { NumberField("Повторения", reps, { reps = it }); NumberField("Вес, кг", weight, { weight = it }, decimal = true) } }, confirmButton = { TextButton(onClick = { onSave(reps.toIntOrNull()?.coerceAtLeast(0) ?: 0, weight.replace(',', '.').toDoubleOrNull() ?: 0.0) }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun PersonalRecordsPanel(dao: WorkoutDao) {
    val records by dao.observePersonalRecords().collectAsState(initial = emptyList())
    val best = records.groupBy { it.exerciseName }.values.mapNotNull { group -> group.maxByOrNull { it.weightKg } }.sortedByDescending { it.weightKg }
    Text("Личные рекорды", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    if (best.isEmpty()) Text("Рекорды появятся после выполнения подходов", color = MaterialTheme.colorScheme.onSurfaceVariant)
    best.forEach { record -> Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(record.exerciseName, fontWeight = FontWeight.SemiBold); Text("${record.actualReps} повторений", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }; Text("${record.weightKg} кг", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) } } }
}

@Composable
private fun TextEntryDialog(title: String, hint: String, action: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value, { value = it }, label = { Text(hint) }, singleLine = true) }, confirmButton = { TextButton(enabled = value.isNotBlank(), onClick = { onSave(value) }) { Text(action) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, decimal: Boolean = false) {
    OutlinedTextField(value, onValue, modifier = modifier, label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number))
}
