package com.lukyanovskykach.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "workout_programs", indices = [Index("updatedAt")])
data class WorkoutProgramEntity(
    @PrimaryKey val id: String,
    val name: String,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "program_exercises", indices = [Index("programId"), Index("orderIndex")])
data class ProgramExerciseEntity(
    @PrimaryKey val id: String,
    val programId: String,
    val name: String,
    val sets: Int = 3,
    val reps: Int = 10,
    val weightKg: Double = 0.0,
    val restSeconds: Int = 90,
    val orderIndex: Int = 0,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null
)

@Entity(tableName = "workout_sessions", indices = [Index("programId"), Index("startedAt"), Index("status")])
data class WorkoutSessionEntity(
    @PrimaryKey val id: String,
    val programId: String?,
    val programName: String,
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null,
    val status: String = "ACTIVE", // ACTIVE, COMPLETED, ABANDONED
    val notes: String? = null
)

@Entity(tableName = "workout_sets", indices = [Index("sessionId"), Index("exerciseId"), Index("completedAt")])
data class WorkoutSetEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val exerciseId: String?,
    val exerciseName: String,
    val setNumber: Int,
    val targetReps: Int,
    val actualReps: Int = 0,
    val weightKg: Double = 0.0,
    val completed: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
