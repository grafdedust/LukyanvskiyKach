<?php
return [
  'dsn' => 'mysql:host=127.0.0.1;dbname=lukyanovsky_kach;charset=utf8mb4',
  'db_user' => 'kach_api',
  'db_password' => 'CHANGE_ME',
  'token_ttl_days' => 30,
];
