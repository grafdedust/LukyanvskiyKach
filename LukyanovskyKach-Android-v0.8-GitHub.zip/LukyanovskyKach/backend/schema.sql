CREATE DATABASE IF NOT EXISTS lukyanovsky_kach CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lukyanovsky_kach;
CREATE TABLE users (
 id CHAR(36) PRIMARY KEY,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 email_verified_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE auth_tokens (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id CHAR(36) NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_tokens_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE sync_records (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id CHAR(36) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id CHAR(36) NOT NULL,
 payload JSON NOT NULL,
 version BIGINT UNSIGNED NOT NULL,
 deleted TINYINT(1) NOT NULL DEFAULT 0,
 updated_at DATETIME(3) NOT NULL,
 UNIQUE KEY uq_entity(user_id,entity_type,entity_id),
 KEY ix_sync_user_version(user_id,version),
 CONSTRAINT fk_sync_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
