<?php
declare(strict_types=1);
// Minimal PHP 8.2+ REST starter. Place behind HTTPS; move config outside web root.
$config = require __DIR__ . '/../config.php';
$pdo = new PDO($config['dsn'], $config['db_user'], $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function body(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function out(array $v,int $status=200): never { http_response_code($status); echo json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH); $method=$_SERVER['REQUEST_METHOD'];
if ($method==='POST' && $path==='/api/v1/auth/register') {
 $b=body(); $email=strtolower(trim((string)($b['email']??''))); $pass=(string)($b['password']??'');
 if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<10) out(['error'=>'Email invalid or password shorter than 10 characters'],422);
 $id=uuid_create(UUID_TYPE_RANDOM); $q=$pdo->prepare('INSERT INTO users(id,email,password_hash) VALUES(?,?,?)');
 try{$q->execute([$id,$email,password_hash($pass,PASSWORD_DEFAULT)]);}catch(Throwable $e){out(['error'=>'Account could not be created'],409);} out(['userId'=>$id,'message'=>'Registration created; add email verification before production use'],201);
}
if ($method==='POST' && $path==='/api/v1/auth/login') {
 $b=body(); $q=$pdo->prepare('SELECT * FROM users WHERE email=?'); $q->execute([strtolower(trim((string)($b['email']??'')))]); $u=$q->fetch();
 if(!$u||!password_verify((string)($b['password']??''),$u['password_hash'])) out(['error'=>'Invalid credentials'],401);
 $token=bin2hex(random_bytes(32)); $hash=hash('sha256',$token); $expires=(new DateTimeImmutable('+'.(int)$config['token_ttl_days'].' days'))->format('Y-m-d H:i:s');
 $q=$pdo->prepare('INSERT INTO auth_tokens(user_id,token_hash,expires_at) VALUES(?,?,?)');$q->execute([$u['id'],$hash,$expires]); out(['userId'=>$u['id'],'accessToken'=>$token,'expiresAt'=>$expires]);
}
$auth=$_SERVER['HTTP_AUTHORIZATION']??''; if(!preg_match('/^Bearer\s+(.+)$/i',$auth,$m)) out(['error'=>'Unauthorized'],401);
$q=$pdo->prepare('SELECT u.id FROM auth_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>UTC_TIMESTAMP()');$q->execute([hash('sha256',$m[1])]);$user=$q->fetch(); if(!$user) out(['error'=>'Unauthorized'],401); $uid=$user['id'];
if($method==='POST'&&$path==='/api/v1/sync/push'){
 $b=body();$items=$b['changes']??[];if(!is_array($items)||count($items)>500)out(['error'=>'Invalid batch'],422);$pdo->beginTransaction();
 $q=$pdo->prepare('INSERT INTO sync_records(user_id,entity_type,entity_id,payload,version,deleted,updated_at) VALUES(?,?,?,?,1,?,UTC_TIMESTAMP(3)) ON DUPLICATE KEY UPDATE payload=VALUES(payload),version=version+1,deleted=VALUES(deleted),updated_at=VALUES(updated_at)');
 foreach($items as $x){$type=(string)($x['type']??'');$id=(string)($x['id']??'');if(!preg_match('/^[a-z_]{2,80}$/',$type)||!preg_match('/^[a-f0-9-]{36}$/i',$id))continue;$q->execute([$uid,$type,$id,json_encode($x['payload']??new stdClass(),JSON_THROW_ON_ERROR),!empty($x['deleted'])?1:0]);}
 $pdo->commit();out(['accepted'=>count($items)]);
}
if($method==='GET'&&$path==='/api/v1/sync/pull'){$since=max(0,(int)($_GET['since']??0));$q=$pdo->prepare('SELECT entity_type,entity_id,payload,version,deleted,UNIX_TIMESTAMP(updated_at)*1000 AS updated_at FROM sync_records WHERE user_id=? AND version>? ORDER BY version LIMIT 1000');$q->execute([$uid,$since]);out(['changes'=>$q->fetchAll()]);}
out(['error'=>'Not found'],404);
